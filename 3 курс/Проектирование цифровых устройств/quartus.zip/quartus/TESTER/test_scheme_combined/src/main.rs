mod data;
mod parse;
mod generate;
mod file;
mod hex;
mod binary;
mod command;
mod simulation;

use std::io;
use std::collections::{LinkedList, HashMap};
use crate::data::TBLData;
use crate::parse::parse;
use crate::generate::generate;
use crate::file::{read_file, write_file};
use crate::binary::{f64_to_b32, b32_to_f64};
use crate::hex::{bin_to_hex};
use crate::command::run_simulation;
use crate::simulation::{simulation, sim_ch, sim_order};




fn main() {


    let project_name = "kursovoy";
    let project_path = "D:\\PCU\\2711\\with_ua_prog_combined\\";
    

    // println!("{}", sim_order(project_path, project_name, 10.0, 5.0));
    // println!("{}", sim_order(project_path, project_name, 5.0, 10.0));
    // println!("{}", sim_order(project_path, project_name, 0.0, 0.0));
    println!("{}", sim_order(project_path, project_name, 0.0, 10.0));
    // println!("{}", sim_order(project_path, project_name, 0.0000000000000000000000529, 288230376151711744.0));
    // println!("{}", sim_order(project_path, project_name, 0.0000000000000000000000529, 281474976710656.0));
    // println!("{}", sim_order(project_path, project_name, 10.0, 15.0));
    // println!("{}", sim_order(project_path, project_name, 33554432.0, 2.0));
    // println!("{}", sim_order(project_path, project_name, 0.0000000149011611938476563, 2.0));



    // println!("{}", sim_order(project_path, project_name, 0.5, 0.5));

    // simulation(project_path, project_name, num1,
    //     num2,
    //     clk_ns,
    //     count_clk);
    //let num1 = bin_to_hex(&format!("{:032b}",f64_to_b32(10.0)));
    

    //let num2 = bin_to_hex(&format!("{:032b}",f64_to_b32(6.0)));
    

}




